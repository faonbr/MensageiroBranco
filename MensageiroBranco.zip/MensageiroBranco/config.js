var config = {
  'APP_DEFAULT_PORT':'3266'
}
module.exports = config;
